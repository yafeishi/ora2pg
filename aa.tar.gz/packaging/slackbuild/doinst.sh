#! /bin/sh
 
cat README

